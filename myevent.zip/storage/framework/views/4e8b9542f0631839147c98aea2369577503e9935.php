<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>
<body>
<h2>Welcome to the site </h2>
<?php
    $verify = \App\Models\VerifyUser::where('user_id',$user->id)->first()
?>
<br/>
Your registered email-id is <?php echo e($user->email); ?> , Please click on the below link to verify your email account
<br/>
<a href="<?php echo e(url('/verify', $verify->token)); ?>">Verify Email</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myevent\resources\views/MailTemplates/verify_mail.blade.php ENDPATH**/ ?>