<!DOCTYPE html>
<html>
<head>
    <title>Password Reset</title>
</head>
<body>
<h2>Password Reset Link </h2>
<br/>
Your registered email-id is <?php echo e($user->email); ?> , Please click on the below link to reset your password
<br/>
<a href="<?php echo e(url('/newpassword')); ?>">Reset</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myevent\resources\views/password_mail.blade.php ENDPATH**/ ?>