<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>
<body>
<h2>Welcome to VesitEvents</h2>
<p><b>Hi, <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></b></p>
<br>
VESIT Event Portal, One Platform for All Events.
<br/>
<br/>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\myevent\resources\views/MailTemplates/welcome_mail.blade.php ENDPATH**/ ?>