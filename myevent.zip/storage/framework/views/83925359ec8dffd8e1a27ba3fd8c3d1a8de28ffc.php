<!DOCTYPE html><head><title></title></head><body></body><?php

/*
*	This is a login-with-google example, you should have credentials for use the api.
*	This isn't store the access token, just retrieves the user information once for store or just display.
*/
include_path='.;c:\xampplite\php'
require_once 'vendor/autoload.php';

$redirect_uri = 'http://localhost:800/myevent/public/';

$google_client = new Google_Client();
$google_client->setApplicationName("Application nam from the PHP");
$google_client->setAuthConfig('oauth-credentials.json');
//$google_client->setClientId('REPLACE_ME.apps.googleusercontent.com');		// alternative for AuthConfig
//$google_client->setClientSecret('REPLACE_ME');
$google_client->setRedirectUri($redirect_uri); // even if there's no redirection, this should be set!
$google_client->setScopes([
    //"profile",	// can give: all we need, but no email
    "email",	// can give: all we need, but no language (do we need that?)
    // https://github.com/google/google-api-php-client-services/blob/master/src/Google/Service/Plus.php#L33
    // the same found in Google_Service_Oauth2
    //Google_Service_Plus::PLUS_LOGIN,		// "https://www.googleapis.com/auth/plus.login"			no email
    //Google_Service_Plus::PLUS_ME,			// "https://www.googleapis.com/auth/plus.me"			no email
    //Google_Service_Plus::USERINFO_EMAIL,	// "https://www.googleapis.com/auth/userinfo.email"		~ "email"
    //Google_Service_Plus::USERINFO_PROFILE,  // "https://www.googleapis.com/auth/userinfo.profile"	~ "profile"
]);
// alternative method:
//$google_client->addScope('https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/plus.login');


if (isset($_GET['error'])){
    print "You didn't give me permissions, i'm so sad :(\n";
    print "<a href='/'>Main</a>";
}elseif(isset($_GET['code'])){
    print "<a href='/'>Login again</a>";
    //if access_token stored: $google_client->setAccessToken($_SESSION["access_token"]);
    $google_client->authenticate($_GET['code']);
    if($google_client->getAccessToken()){
        print "\n\n#\n\n";
        print "acces token exists";
    }else{
        print "\n\n#\n\n";
        print "access_token not exists !!!!";
    }
    if($google_client->isAccessTokenExpired()){	// not need for real, since we don't store, and it's valid for
        print "\n\n#\n\n";
        print "!!!!!!!!!!!!!! ACCESS TOKEN EXPIRED !!!!!!!!";
    }else{
        print "\n\n#\n\n";
        print "access token not expired";
    }
    /*
    *	Need: id,email,fullname,firstname,lastname,gender,timezone,timezone_gmt_offset,birthday,education[school,year]
    *
        need google plus account for birthday,gender,organizations(educations)
        birthday only available if user set it's display to public

    */

    $google_oauth2 = new Google_Service_Oauth2($google_client);
    $google_user = $google_oauth2->userinfo->get();
    print "\n\n#\n\n";
    //print '<img src="'.$google_user->picture.'" style="float: right;margin-top: 33px;" />'."\n\n";
    print "id:				".$google_user->id."\n";
    print "email:			".$google_user->email."\n";
    //print "verified-email:	".$google_user->verifiedEmail."\n";	// just interesting if != "1"
    print "full-name:		".$google_user->name."\n";
    print "first-name:		".$google_user->givenName."\n";
    print "last-name:		".$google_user->familyName."\n";
    print "gender:			".$google_user->gender."\n";
    print "language:		".$google_user->locale."\n";
    // no birthday :(

    /* other solution with Plus: can give: birthday,organizations,occupation */

    $google_plus = new Google_Service_Plus($google_client);
    $google_me = $google_plus->people->get('me');
    print "\n\n#\n\n";
    print "id:			".$google_me->id."\n";
    print "email:		".$google_me->emails[0]->value."\n";
    print "fulname:		".$google_me->displayName."\n";
    print "firstname:	".$google_me->name->givenName."\n";
    print "lastname:	".$google_me->name->familyName."\n";
    print "gender:		".$google_me->gender."\n";
    print "language:	".$google_me->language."\n";
    print "birthday:	".$google_me->birthday."\n";		// if available, the year still can be 0000 eg: "0000-05-09"
    if($google_me->organizations && count($google_me->organizations)>0){
        print "educ-school:	".$google_me->organizations[0]->name." : ".$google_me->organizations[0]->title."\n";
        print "educ-year:	".$google_me->organizations[0]->startDate."-".$google_me->organizations[0]->endDate."\n";
    }else{
        print "no organization";
    }
    print "occupation:	".$google_me->occupation."\n";


    // print all:
    print "\n\n# everything from Oauth2:\n\n";
    print_r($google_user);
    print "\n\n# everything from Plus:\n\n";
    print_r($google_me);

    // everything should be safe:
    try {
        // do google stuff
    } catch (Google_Exception $e) {
        print "\n\n#ERROR#\n\n";
        print_r($e);
    }
}else{
    $google_auth_url = $google_client->createAuthUrl();
    print "<a href='".$google_auth_url."'>Login</a>";
    //header("Location: ".$google_auth_url);
}

print "\n\n<br><br><br><br>";
 ?><?php /**PATH C:\xampp\htdocs\myevent\resources\views/temp2.blade.php ENDPATH**/ ?>