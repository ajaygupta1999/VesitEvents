<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>
<body>
<h2>Welcome to VesitEvents</h2>
<p><b>Hi, {{$user->first_name}} {{$user->last_name}}</b></p>
<br>
VESIT Event Portal, One Platform for All Events.
<br/>
<br/>
</body>
</html>
